export { default as AboutUsPage } from './AboutUsPage/AboutUsPage';
export { default as HomePageBDS } from './HomePageBDS/HomePageBDS';
export { default as ProductsPage } from './ProductsPage/ProductsPage';
export { default as CartPage } from './CartPage/CartPage';
export { default as HomePage } from './HomePage/App';